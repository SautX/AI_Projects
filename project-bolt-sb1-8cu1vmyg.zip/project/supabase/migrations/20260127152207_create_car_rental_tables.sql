/*
  # Car Rental Platform Database Schema

  1. New Tables
    - `locations`
      - `id` (uuid, primary key)
      - `name` (text) - Location name
      - `address` (text) - Full address
      - `city` (text) - City name
      - `country` (text) - Country
      - `created_at` (timestamptz)
    
    - `cars`
      - `id` (uuid, primary key)
      - `brand` (text) - Car brand (e.g., BMW, Mercedes, Toyota)
      - `model` (text) - Car model
      - `year` (integer) - Manufacturing year
      - `category` (text) - SUV, Sedan, Sports, Luxury, etc.
      - `seats` (integer) - Number of seats
      - `transmission` (text) - Automatic or Manual
      - `fuel_type` (text) - Petrol, Diesel, Electric, Hybrid
      - `price_per_day` (numeric) - Daily rental price
      - `image_url` (text) - Car image URL
      - `logo_url` (text) - Brand logo URL
      - `features` (text[]) - Array of features
      - `available` (boolean) - Availability status
      - `location_id` (uuid) - Foreign key to locations
      - `created_at` (timestamptz)
    
    - `bookings`
      - `id` (uuid, primary key)
      - `car_id` (uuid) - Foreign key to cars
      - `pickup_location_id` (uuid) - Foreign key to locations
      - `dropoff_location_id` (uuid) - Foreign key to locations
      - `pickup_date` (date) - Pickup date
      - `dropoff_date` (date) - Dropoff date
      - `customer_name` (text) - Customer name
      - `customer_email` (text) - Customer email
      - `customer_phone` (text) - Customer phone
      - `total_price` (numeric) - Total booking price
      - `status` (text) - pending, confirmed, completed, cancelled
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for public read access to cars and locations
    - Add policies for booking management
*/

-- Create locations table
CREATE TABLE IF NOT EXISTS locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  country text NOT NULL DEFAULT 'USA',
  created_at timestamptz DEFAULT now()
);

-- Create cars table
CREATE TABLE IF NOT EXISTS cars (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand text NOT NULL,
  model text NOT NULL,
  year integer NOT NULL,
  category text NOT NULL,
  seats integer NOT NULL DEFAULT 5,
  transmission text NOT NULL DEFAULT 'Automatic',
  fuel_type text NOT NULL DEFAULT 'Petrol',
  price_per_day numeric NOT NULL,
  image_url text NOT NULL,
  logo_url text NOT NULL,
  features text[] DEFAULT '{}',
  available boolean DEFAULT true,
  location_id uuid REFERENCES locations(id),
  created_at timestamptz DEFAULT now()
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  car_id uuid REFERENCES cars(id) NOT NULL,
  pickup_location_id uuid REFERENCES locations(id) NOT NULL,
  dropoff_location_id uuid REFERENCES locations(id) NOT NULL,
  pickup_date date NOT NULL,
  dropoff_date date NOT NULL,
  customer_name text NOT NULL,
  customer_email text NOT NULL,
  customer_phone text NOT NULL,
  total_price numeric NOT NULL,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE cars ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Policies for locations (public read)
CREATE POLICY "Anyone can view locations"
  ON locations FOR SELECT
  USING (true);

-- Policies for cars (public read)
CREATE POLICY "Anyone can view cars"
  ON cars FOR SELECT
  USING (true);

-- Policies for bookings (public insert, own data read)
CREATE POLICY "Anyone can create bookings"
  ON bookings FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can view bookings"
  ON bookings FOR SELECT
  USING (true);
