export interface Database {
  public: {
    Tables: {
      locations: {
        Row: {
          id: string;
          name: string;
          address: string;
          city: string;
          country: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          address: string;
          city: string;
          country?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          address?: string;
          city?: string;
          country?: string;
          created_at?: string;
        };
      };
      cars: {
        Row: {
          id: string;
          brand: string;
          model: string;
          year: number;
          category: string;
          seats: number;
          transmission: string;
          fuel_type: string;
          price_per_day: number;
          image_url: string;
          logo_url: string;
          features: string[];
          available: boolean;
          location_id: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          brand: string;
          model: string;
          year: number;
          category: string;
          seats?: number;
          transmission?: string;
          fuel_type?: string;
          price_per_day: number;
          image_url: string;
          logo_url: string;
          features?: string[];
          available?: boolean;
          location_id?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          brand?: string;
          model?: string;
          year?: number;
          category?: string;
          seats?: number;
          transmission?: string;
          fuel_type?: string;
          price_per_day?: number;
          image_url?: string;
          logo_url?: string;
          features?: string[];
          available?: boolean;
          location_id?: string | null;
          created_at?: string;
        };
      };
      bookings: {
        Row: {
          id: string;
          car_id: string;
          pickup_location_id: string;
          dropoff_location_id: string;
          pickup_date: string;
          dropoff_date: string;
          customer_name: string;
          customer_email: string;
          customer_phone: string;
          total_price: number;
          status: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          car_id: string;
          pickup_location_id: string;
          dropoff_location_id: string;
          pickup_date: string;
          dropoff_date: string;
          customer_name: string;
          customer_email: string;
          customer_phone: string;
          total_price: number;
          status?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          car_id?: string;
          pickup_location_id?: string;
          dropoff_location_id?: string;
          pickup_date?: string;
          dropoff_date?: string;
          customer_name?: string;
          customer_email?: string;
          customer_phone?: string;
          total_price?: number;
          status?: string;
          created_at?: string;
        };
      };
    };
  };
}

export type Location = Database['public']['Tables']['locations']['Row'];
export type Car = Database['public']['Tables']['cars']['Row'];
export type Booking = Database['public']['Tables']['bookings']['Row'];
