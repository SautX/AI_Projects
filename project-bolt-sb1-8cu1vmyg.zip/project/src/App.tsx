import { useState } from 'react';
import Navigation from './components/Navigation';
import HomePage from './pages/HomePage';
import CarsPage from './pages/CarsPage';
import CarDetailsPage from './pages/CarDetailsPage';
import LocationsPage from './pages/LocationsPage';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedCarId, setSelectedCarId] = useState<string>('');

  function handleNavigate(page: string, carId?: string) {
    setCurrentPage(page);
    if (carId) setSelectedCarId(carId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation currentPage={currentPage} onNavigate={handleNavigate} />

      {currentPage === 'home' && <HomePage onNavigate={handleNavigate} />}
      {currentPage === 'cars' && <CarsPage onNavigate={handleNavigate} />}
      {currentPage === 'car-details' && (
        <CarDetailsPage carId={selectedCarId} onNavigate={handleNavigate} />
      )}
      {currentPage === 'locations' && <LocationsPage />}
    </div>
  );
}

export default App;
