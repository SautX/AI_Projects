import { useEffect, useState } from 'react';
import { ArrowLeft, Check, MapPin, Calendar, User, Mail, Phone } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Car, Location } from '../lib/database.types';

interface CarDetailsPageProps {
  carId: string;
  onNavigate: (page: string) => void;
}

export default function CarDetailsPage({ carId, onNavigate }: CarDetailsPageProps) {
  const [car, setCar] = useState<Car | null>(null);
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);

  const [formData, setFormData] = useState({
    pickupLocationId: '',
    dropoffLocationId: '',
    pickupDate: '',
    dropoffDate: '',
    customerName: '',
    customerEmail: '',
    customerPhone: '',
  });

  useEffect(() => {
    fetchCarDetails();
  }, [carId]);

  async function fetchCarDetails() {
    try {
      const [carResult, locationsResult] = await Promise.all([
        supabase.from('cars').select('*').eq('id', carId).single(),
        supabase.from('locations').select('*'),
      ]);

      if (carResult.data) setCar(carResult.data);
      if (locationsResult.data) setLocations(locationsResult.data);
    } catch (error) {
      console.error('Error fetching car details:', error);
    } finally {
      setLoading(false);
    }
  }

  function calculateTotalPrice() {
    if (!car || !formData.pickupDate || !formData.dropoffDate) return 0;

    const pickup = new Date(formData.pickupDate);
    const dropoff = new Date(formData.dropoffDate);
    const days = Math.ceil((dropoff.getTime() - pickup.getTime()) / (1000 * 60 * 60 * 24));

    return days * car.price_per_day;
  }

  async function handleBooking(e: React.FormEvent) {
    e.preventDefault();

    if (!car) return;

    try {
      const totalPrice = calculateTotalPrice();

      const { error } = await supabase.from('bookings').insert({
        car_id: car.id,
        pickup_location_id: formData.pickupLocationId,
        dropoff_location_id: formData.dropoffLocationId,
        pickup_date: formData.pickupDate,
        dropoff_date: formData.dropoffDate,
        customer_name: formData.customerName,
        customer_email: formData.customerEmail,
        customer_phone: formData.customerPhone,
        total_price: totalPrice,
        status: 'pending',
      });

      if (error) throw error;

      setBookingSuccess(true);
      setTimeout(() => {
        onNavigate('home');
      }, 3000);
    } catch (error) {
      console.error('Error creating booking:', error);
      alert('Failed to create booking. Please try again.');
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!car) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl text-gray-600 mb-4">Car not found</p>
          <button
            onClick={() => onNavigate('cars')}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Back to Fleet
          </button>
        </div>
      </div>
    );
  }

  if (bookingSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-12 rounded-2xl shadow-xl text-center max-w-md">
          <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Booking Confirmed!</h2>
          <p className="text-gray-600 mb-6">
            Your booking has been successfully submitted. We'll send a confirmation email to{' '}
            {formData.customerEmail}
          </p>
          <div className="bg-blue-50 p-4 rounded-lg mb-6">
            <p className="text-sm text-gray-700 font-semibold">Total Amount</p>
            <p className="text-3xl font-bold text-blue-600">${calculateTotalPrice()}</p>
          </div>
          <p className="text-sm text-gray-500">Redirecting to home...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <button
            onClick={() => onNavigate('cars')}
            className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Fleet
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <div className="relative rounded-2xl overflow-hidden shadow-2xl mb-6">
              <img
                src={car.image_url}
                alt={`${car.brand} ${car.model}`}
                className="w-full h-96 object-cover"
              />
              <div className="absolute top-6 right-6 bg-white p-3 rounded-lg shadow-lg">
                <img src={car.logo_url} alt={car.brand} className="h-12 w-auto" />
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h1 className="text-4xl font-bold text-gray-900 mb-2">
                    {car.brand} {car.model}
                  </h1>
                  <p className="text-xl text-gray-600">{car.category}</p>
                </div>
                {car.available && (
                  <span className="bg-green-500 text-white px-4 py-2 rounded-full text-sm font-semibold">
                    Available
                  </span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6 pb-6 border-b border-gray-200">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Year</p>
                  <p className="text-lg font-semibold text-gray-900">{car.year}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Seats</p>
                  <p className="text-lg font-semibold text-gray-900">{car.seats} Passengers</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Transmission</p>
                  <p className="text-lg font-semibold text-gray-900">{car.transmission}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Fuel Type</p>
                  <p className="text-lg font-semibold text-gray-900">{car.fuel_type}</p>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Features</h3>
                <div className="grid grid-cols-2 gap-3">
                  {car.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Check className="w-5 h-5 text-green-500" />
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div>
            <div className="bg-white rounded-2xl shadow-lg p-8 sticky top-24">
              <div className="bg-blue-50 p-6 rounded-xl mb-6">
                <p className="text-sm text-gray-600 mb-2">Daily Rate</p>
                <p className="text-5xl font-bold text-blue-600">${car.price_per_day}</p>
                <p className="text-sm text-gray-500 mt-1">per day</p>
              </div>

              {!showBookingForm ? (
                <button
                  onClick={() => setShowBookingForm(true)}
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-4 rounded-lg font-semibold text-lg hover:from-blue-700 hover:to-blue-800 transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  Book This Car
                </button>
              ) : (
                <form onSubmit={handleBooking} className="space-y-4">
                  <h3 className="text-2xl font-bold text-gray-900 mb-6">Booking Details</h3>

                  <div>
                    <label className="flex items-center text-sm font-semibold text-gray-700 mb-2">
                      <MapPin className="w-4 h-4 mr-2 text-blue-600" />
                      Pickup Location
                    </label>
                    <select
                      required
                      value={formData.pickupLocationId}
                      onChange={(e) =>
                        setFormData({ ...formData, pickupLocationId: e.target.value })
                      }
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none transition-colors"
                    >
                      <option value="">Select location</option>
                      {locations.map((loc) => (
                        <option key={loc.id} value={loc.id}>
                          {loc.name} - {loc.city}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="flex items-center text-sm font-semibold text-gray-700 mb-2">
                      <MapPin className="w-4 h-4 mr-2 text-blue-600" />
                      Dropoff Location
                    </label>
                    <select
                      required
                      value={formData.dropoffLocationId}
                      onChange={(e) =>
                        setFormData({ ...formData, dropoffLocationId: e.target.value })
                      }
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none transition-colors"
                    >
                      <option value="">Select location</option>
                      {locations.map((loc) => (
                        <option key={loc.id} value={loc.id}>
                          {loc.name} - {loc.city}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="flex items-center text-sm font-semibold text-gray-700 mb-2">
                      <Calendar className="w-4 h-4 mr-2 text-blue-600" />
                      Pickup Date
                    </label>
                    <input
                      type="date"
                      required
                      min={new Date().toISOString().split('T')[0]}
                      value={formData.pickupDate}
                      onChange={(e) => setFormData({ ...formData, pickupDate: e.target.value })}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none transition-colors"
                    />
                  </div>

                  <div>
                    <label className="flex items-center text-sm font-semibold text-gray-700 mb-2">
                      <Calendar className="w-4 h-4 mr-2 text-blue-600" />
                      Dropoff Date
                    </label>
                    <input
                      type="date"
                      required
                      min={formData.pickupDate || new Date().toISOString().split('T')[0]}
                      value={formData.dropoffDate}
                      onChange={(e) => setFormData({ ...formData, dropoffDate: e.target.value })}
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none transition-colors"
                    />
                  </div>

                  <div className="pt-4 border-t border-gray-200">
                    <h4 className="font-semibold text-gray-900 mb-4">Contact Information</h4>

                    <div className="space-y-4">
                      <div>
                        <label className="flex items-center text-sm font-semibold text-gray-700 mb-2">
                          <User className="w-4 h-4 mr-2 text-blue-600" />
                          Full Name
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.customerName}
                          onChange={(e) =>
                            setFormData({ ...formData, customerName: e.target.value })
                          }
                          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none transition-colors"
                          placeholder="John Doe"
                        />
                      </div>

                      <div>
                        <label className="flex items-center text-sm font-semibold text-gray-700 mb-2">
                          <Mail className="w-4 h-4 mr-2 text-blue-600" />
                          Email
                        </label>
                        <input
                          type="email"
                          required
                          value={formData.customerEmail}
                          onChange={(e) =>
                            setFormData({ ...formData, customerEmail: e.target.value })
                          }
                          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none transition-colors"
                          placeholder="john@example.com"
                        />
                      </div>

                      <div>
                        <label className="flex items-center text-sm font-semibold text-gray-700 mb-2">
                          <Phone className="w-4 h-4 mr-2 text-blue-600" />
                          Phone
                        </label>
                        <input
                          type="tel"
                          required
                          value={formData.customerPhone}
                          onChange={(e) =>
                            setFormData({ ...formData, customerPhone: e.target.value })
                          }
                          className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none transition-colors"
                          placeholder="+1 (555) 123-4567"
                        />
                      </div>
                    </div>
                  </div>

                  {formData.pickupDate && formData.dropoffDate && (
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-700">Total Days</span>
                        <span className="font-semibold text-gray-900">
                          {Math.ceil(
                            (new Date(formData.dropoffDate).getTime() -
                              new Date(formData.pickupDate).getTime()) /
                              (1000 * 60 * 60 * 24)
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-700 font-semibold">Total Price</span>
                        <span className="text-2xl font-bold text-blue-600">
                          ${calculateTotalPrice()}
                        </span>
                      </div>
                    </div>
                  )}

                  <div className="flex space-x-3">
                    <button
                      type="button"
                      onClick={() => setShowBookingForm(false)}
                      className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-300 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="flex-1 bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 rounded-lg font-semibold hover:from-blue-700 hover:to-blue-800 transition-all duration-200 shadow-lg"
                    >
                      Confirm Booking
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
