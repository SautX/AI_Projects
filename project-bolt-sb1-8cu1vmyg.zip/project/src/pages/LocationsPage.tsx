import { useEffect, useState } from 'react';
import { MapPin, Phone, Clock } from 'lucide-react';
import { supabase } from '../lib/supabase';
import type { Location } from '../lib/database.types';

export default function LocationsPage() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLocations();
  }, []);

  async function fetchLocations() {
    try {
      const { data, error } = await supabase.from('locations').select('*').order('city');

      if (error) throw error;
      if (data) setLocations(data);
    } catch (error) {
      console.error('Error fetching locations:', error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <MapPin className="w-16 h-16 mx-auto mb-6" />
            <h1 className="text-5xl font-bold mb-4">Our Locations</h1>
            <p className="text-xl text-blue-100">
              Find a DriveNow rental location near you
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <>
            <div className="text-center mb-12">
              <p className="text-xl text-gray-600">
                We have {locations.length} convenient locations across the country
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {locations.map((location) => (
                <div
                  key={location.id}
                  className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden transform hover:-translate-y-1"
                >
                  <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-6">
                    <div className="flex items-center space-x-3 mb-2">
                      <div className="bg-white p-2 rounded-lg">
                        <MapPin className="w-6 h-6 text-blue-600" />
                      </div>
                      <h3 className="text-2xl font-bold text-white">{location.name}</h3>
                    </div>
                    <p className="text-blue-100 text-lg">{location.city}, {location.country}</p>
                  </div>

                  <div className="p-6 space-y-4">
                    <div className="flex items-start space-x-3">
                      <MapPin className="w-5 h-5 text-gray-400 mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-semibold text-gray-700 mb-1">Address</p>
                        <p className="text-gray-600">{location.address}</p>
                        <p className="text-gray-600">
                          {location.city}, {location.country}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Clock className="w-5 h-5 text-gray-400 mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-semibold text-gray-700 mb-1">Hours</p>
                        <p className="text-gray-600">Mon-Fri: 8:00 AM - 8:00 PM</p>
                        <p className="text-gray-600">Sat-Sun: 9:00 AM - 6:00 PM</p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Phone className="w-5 h-5 text-gray-400 mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-semibold text-gray-700 mb-1">Contact</p>
                        <p className="text-gray-600">+1 (555) 123-4567</p>
                        <p className="text-blue-600 text-sm">info@drivenow.com</p>
                      </div>
                    </div>

                    <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors mt-4">
                      Get Directions
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-16 bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">
                Location Features
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MapPin className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    Convenient Locations
                  </h3>
                  <p className="text-gray-600">
                    Strategically located in major cities and airports
                  </p>
                </div>

                <div className="text-center">
                  <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Clock className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    Extended Hours
                  </h3>
                  <p className="text-gray-600">
                    Open early and late to accommodate your schedule
                  </p>
                </div>

                <div className="text-center">
                  <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Phone className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    24/7 Support
                  </h3>
                  <p className="text-gray-600">
                    Customer service available around the clock
                  </p>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
